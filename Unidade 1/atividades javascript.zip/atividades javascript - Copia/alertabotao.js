// let button = document.getElementById('button')

// button.emitirAlerta = function () {
//     window.alert("Júlia meu amor")  
//  }
 
button = function(texto) {
    window.alert("Júlia meu amor")
}