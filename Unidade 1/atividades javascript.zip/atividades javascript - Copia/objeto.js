let livro = {
    titulo:'',
    autor:'',
    numeroDePaginas:'',
}
livro.autor = 'moises'
livro.titulo = 'o retrato de dorian gray'
livro.numeroDePaginas = '267'
console.log(livro.autor)
console.log(livro.titulo)
console.log(livro.numeroDePaginas)