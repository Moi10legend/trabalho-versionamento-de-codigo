 
button = function(texto) {
    window.alert("Você clicou no botão")
}