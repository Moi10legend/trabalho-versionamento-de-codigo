

button2 = function() {
    let frase = prompt("Escreva uma frase")
    window.alert(frase)
}