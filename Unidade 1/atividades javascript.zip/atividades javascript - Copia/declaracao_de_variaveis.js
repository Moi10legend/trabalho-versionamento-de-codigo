let nome = 'Júlia'
let idade = 17
let comidaFavorita = ''
comidaFavorita = 'camarão'
let variavel1
let variavel2
let variavel3
let variavel4
let variavel5

