let frutasFavoritas = ['morango','melancia', 'moises freire lopes filho','maracujá','laranja']
for (let i = 0; i < frutasFavoritas.length; i++) {
    console.log(frutasFavoritas[i])
    
}