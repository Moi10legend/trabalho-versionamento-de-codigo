function soma(a, b) {
    return a + b;
}


let resultado = soma(156, 251);
console.log(resultado); 